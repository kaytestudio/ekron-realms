import { useCallback, useEffect, useRef, useState } from 'react';
import Compass from './components/Compass';
import Minimap from './components/Minimap';
import { POIS } from './world/layout';
import { createWorld, Mode, TimeOfDay, WorldHandle } from './world/createWorld';

interface Ui {
  mode: Mode;
  locked: boolean;
  yaw: number;
  x: number;
  z: number;
  fps: number;
  speed: number;
}

const TIMES: { id: TimeOfDay; label: string }[] = [
  { id: 'dusk', label: 'ЗАКАТ' },
  { id: 'day', label: 'ДЕНЬ' },
  { id: 'night', label: 'НОЧЬ' },
];

function Bracket({ className = '' }: { className?: string }) {
  return (
    <>
      <span className={`pointer-events-none absolute left-0 top-0 h-2.5 w-2.5 border-l-2 border-t-2 border-[#ffb13b] ${className}`} />
      <span className={`pointer-events-none absolute right-0 top-0 h-2.5 w-2.5 border-r-2 border-t-2 border-[#ffb13b] ${className}`} />
      <span className={`pointer-events-none absolute bottom-0 left-0 h-2.5 w-2.5 border-b-2 border-l-2 border-[#ffb13b] ${className}`} />
      <span className={`pointer-events-none absolute bottom-0 right-0 h-2.5 w-2.5 border-b-2 border-r-2 border-[#ffb13b] ${className}`} />
    </>
  );
}

function Panel({ title, children, className = '' }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative border border-[#4a5033] bg-[#0b0e08]/80 p-3 backdrop-blur-sm ${className}`}>
      <Bracket />
      <div className="font-stencil mb-2 text-[11px] tracking-[0.2em] text-[#ffb13b]">{title}</div>
      {children}
    </div>
  );
}

function Btn({ active, onClick, children, className = '' }: { active?: boolean; onClick: () => void; children: React.ReactNode; className?: string }) {
  return (
    <button
      onClick={(e) => {
        onClick();
        e.currentTarget.blur();
      }}
      className={`font-mil border px-2 py-1.5 text-[12px] tracking-wider transition-colors ${
        active ? 'border-[#ffb13b] bg-[#ffb13b] text-[#14110a]' : 'border-[#4a5033] bg-[#151a0f]/80 text-[#c9c19a] hover:border-[#ffb13b] hover:text-[#ffb13b]'
      } ${className}`}
    >
      {children}
    </button>
  );
}

export default function App() {
  const hostRef = useRef<HTMLDivElement>(null);
  const [world, setWorld] = useState<WorldHandle | null>(null);
  const [ui, setUi] = useState<Ui>({ mode: 'orbit', locked: false, yaw: 0, x: 0, z: 0, fps: 0, speed: 0 });
  const [entered, setEntered] = useState(false);
  const [time, setTime] = useState<TimeOfDay>('dusk');
  const [muted, setMuted] = useState(false);
  const [showMap, setShowMap] = useState(true);
  const [showPanel, setShowPanel] = useState(true);

  // создаём мир (с небольшой задержкой, чтобы успел отрисоваться экран загрузки)
  useEffect(() => {
    let w: WorldHandle | null = null;
    let timer = 0;
    const t = window.setTimeout(() => {
      w = createWorld(hostRef.current!);
      setWorld(w);
      timer = window.setInterval(() => {
        const s = w!.state;
        setUi({ mode: s.mode, locked: s.locked, yaw: s.yaw, x: s.x, z: s.z, fps: s.fps, speed: s.speed });
      }, 100);
    }, 80);
    return () => {
      clearTimeout(t);
      clearInterval(timer);
      w?.dispose();
      setWorld(null);
    };
  }, []);

  const enter = useCallback(
    (mode: Mode) => {
      if (!world) return;
      setEntered(true);
      world.startAudio();
      world.setMode(mode);
      if (mode === 'fps') world.lock();
    },
    [world]
  );

  const changeTime = useCallback(
    (t: TimeOfDay) => {
      setTime(t);
      world?.setTime(t);
    },
    [world]
  );

  // горячие клавиши
  useEffect(() => {
    if (!world || !entered) return;
    const onKey = (e: KeyboardEvent) => {
      const n = parseInt(e.key, 10);
      if (n >= 1 && n <= POIS.length) {
        const p = POIS[n - 1];
        world.teleport(p.x, p.z, p.yaw);
      }
      if (e.code === 'KeyT') {
        const order: TimeOfDay[] = ['dusk', 'day', 'night'];
        setTime((cur) => {
          const next = order[(order.indexOf(cur) + 1) % order.length];
          world.setTime(next);
          return next;
        });
      }
      if (e.code === 'KeyM') setShowMap((v) => !v);
      if (e.code === 'KeyH') setShowPanel((v) => !v);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [world, entered]);

  const heading = Math.round((((-ui.yaw * 180) / Math.PI) % 360 + 360) % 360);
  const col = String.fromCharCode(65 + Math.max(0, Math.min(11, Math.floor((ui.x + 144) / 24))));
  const row = Math.max(1, Math.min(12, Math.floor((ui.z + 144) / 24) + 1));
  const fps = ui.mode === 'fps';

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black text-[#d8d2b0] select-none">
      <div ref={hostRef} className="absolute inset-0" />

      {/* виньетка и зерно */}
      <div className="pointer-events-none absolute inset-0" style={{ background: 'radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.65) 100%)' }} />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.16] mix-blend-overlay"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>\")",
        }}
      />

      {!world && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#0a0c07]">
          <div className="font-stencil text-3xl tracking-[0.3em] text-[#ffb13b]">ЗАГРУЗКА КАРТЫ</div>
          <div className="font-mil mt-3 text-sm text-[#8b8a6c]">генерация города · разрушение зданий · расстановка техники…</div>
          <div className="mt-6 h-1 w-64 overflow-hidden bg-[#1c2012]">
            <div className="h-full w-1/3 animate-[load_1.1s_ease-in-out_infinite] bg-[#ffb13b]" />
          </div>
        </div>
      )}

      {world && entered && (
        <>
          {/* заголовок */}
          <div className="pointer-events-none absolute left-4 top-4 hidden xl:block">
            <div className="font-stencil text-[22px] leading-none tracking-wider text-[#ffb13b]">ПЕПЕЛЬНЫЙ КВАРТАЛ</div>
            <div className="font-mil mt-1 text-[11px] tracking-[0.25em] text-[#a9a37f]">СЕКТОР 7 · РАЗРУШЕННЫЙ ГОРОД</div>
            <div className="font-mil mt-2 inline-block border border-[#ff5a3c]/70 bg-[#ff5a3c]/10 px-2 py-0.5 text-[10px] tracking-[0.2em] text-[#ff7a5c]">● ЗОНА БОЕВЫХ ДЕЙСТВИЙ</div>
          </div>

          {/* компас */}
          <div className="pointer-events-none absolute left-1/2 top-3 flex -translate-x-1/2 flex-col items-center">
            <Compass yaw={ui.yaw} />
            <div className="font-mil mt-1 text-[11px] tracking-[0.3em] text-[#ffb13b]">АЗИМУТ {String(heading).padStart(3, '0')}°</div>
          </div>

          {/* прицел */}
          {fps && (
            <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="h-1 w-1 rounded-full bg-[#f4f0b8]/80" />
              <div className="absolute -left-3 top-0 h-px w-2 bg-[#f4f0b8]/50" />
              <div className="absolute -right-2 top-0 h-px w-2 bg-[#f4f0b8]/50" />
            </div>
          )}

          {/* миникарта */}
          <div className="absolute bottom-4 left-4">
            <div className="relative border border-[#4a5033] bg-[#06100a]/90 p-1.5 shadow-[0_0_30px_rgba(0,0,0,0.6)]">
              <Bracket />
              <div className="font-mil mb-1 flex items-center justify-between px-0.5 text-[10px] tracking-[0.2em] text-[#7fd08a]">
                <span>ТАКТИЧЕСКАЯ КАРТА</span>
                <button onClick={() => setShowMap((v) => !v)} className="pointer-events-auto text-[#ffb13b]">
                  {showMap ? '[–]' : '[+]'}
                </button>
              </div>
              <Minimap world={world} visible={showMap} />
              <div className="font-mil mt-1 flex justify-between px-0.5 text-[10px] tracking-wider text-[#7fd08a]">
                <span>
                  КВ {col}-{String(row).padStart(2, '0')}
                </span>
                <span>
                  X{Math.round(ui.x)} Z{Math.round(ui.z)}
                </span>
                <span>{ui.fps} FPS</span>
              </div>
            </div>
          </div>

          {/* правая панель */}
          <div className="absolute right-4 top-4 flex w-[250px] flex-col items-end gap-2">
            <Btn onClick={() => setShowPanel((v) => !v)} className="w-fit">
              {showPanel ? 'СКРЫТЬ [H]' : 'ПАНЕЛЬ [H]'}
            </Btn>
            {showPanel && (
              <div className="flex w-full flex-col gap-2">
                <Panel title="РЕЖИМ ОБЗОРА">
                  <div className="grid grid-cols-2 gap-1.5">
                    <Btn
                      active={fps}
                      onClick={() => {
                        world.setMode('fps');
                        world.lock();
                      }}
                    >
                      ОТ 1-ГО ЛИЦА
                    </Btn>
                    <Btn active={!fps} onClick={() => world.setMode('orbit')}>
                      СВЕРХУ
                    </Btn>
                  </div>
                  <div className="font-mil mt-2 text-[10px] leading-relaxed text-[#8b8a6c]">[V] — переключить режим</div>
                </Panel>

                <Panel title="ВРЕМЯ СУТОК">
                  <div className="grid grid-cols-3 gap-1.5">
                    {TIMES.map((t) => (
                      <Btn key={t.id} active={time === t.id} onClick={() => changeTime(t.id)}>
                        {t.label}
                      </Btn>
                    ))}
                  </div>
                  <div className="font-mil mt-2 text-[10px] text-[#8b8a6c]">[T] — сменить</div>
                </Panel>

                <Panel title="ТОЧКИ ИНТЕРЕСА">
                  <div className="flex flex-col gap-1">
                    {POIS.map((p, i) => (
                      <button
                        key={p.id}
                        onClick={(e) => {
                          world.teleport(p.x, p.z, p.yaw);
                          e.currentTarget.blur();
                        }}
                        className="group flex items-start gap-2 border border-transparent px-1 py-1 text-left hover:border-[#4a5033] hover:bg-[#151a0f]"
                      >
                        <span className="font-stencil mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center border border-[#ffb13b] text-[11px] text-[#ffb13b]">{i + 1}</span>
                        <span>
                          <span className="font-mil block text-[12px] leading-tight text-[#e6dfb8] group-hover:text-[#ffb13b]">{p.name}</span>
                          <span className="font-mil block text-[10px] leading-tight text-[#8b8a6c]">{p.desc}</span>
                        </span>
                      </button>
                    ))}
                  </div>
                </Panel>

                <Panel title="ОБСТАНОВКА">
                  <div className="font-mil grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
                    <span className="text-[#8b8a6c]">Танки</span>
                    <span className="text-right text-[#ffb13b]">{world.map.stats.tanks}</span>
                    <span className="text-[#8b8a6c]">Машины</span>
                    <span className="text-right text-[#c9c19a]">{world.map.stats.cars}</span>
                    <span className="text-[#8b8a6c]">Здания</span>
                    <span className="text-right text-[#c9c19a]">{world.map.stats.buildings}</span>
                    <span className="text-[#8b8a6c]">Очаги огня</span>
                    <span className="text-right text-[#ff7a5c]">{world.map.stats.fires}</span>
                  </div>
                  <div className="mt-2 flex gap-1.5">
                    <Btn
                      className="flex-1"
                      active={!muted}
                      onClick={() => {
                        const m = !muted;
                        setMuted(m);
                        world.setMuted(m);
                      }}
                    >
                      {muted ? 'ЗВУК: ВЫКЛ' : 'ЗВУК: ВКЛ'}
                    </Btn>
                    <Btn className="flex-1" active={showMap} onClick={() => setShowMap((v) => !v)}>
                      КАРТА [M]
                    </Btn>
                  </div>
                </Panel>
              </div>
            )}
          </div>

          {/* подсказка */}
          <div className="pointer-events-none absolute bottom-4 left-1/2 -translate-x-1/2 text-center">
            {fps && !ui.locked ? (
              <div className="font-stencil animate-pulse border border-[#ffb13b] bg-black/70 px-4 py-2 text-sm tracking-[0.2em] text-[#ffb13b]">КЛИК ПО ЭКРАНУ — ЗАХВАТ МЫШИ</div>
            ) : (
              <div className="font-mil border border-[#4a5033] bg-black/55 px-3 py-1.5 text-[11px] tracking-wider text-[#a9a37f]">
                {fps ? 'WASD — ход · SHIFT — бег · МЫШЬ — обзор · Q/E — поворот · 1–6 — точки · V — сверху · ESC — курсор' : 'ЛКМ — вращать · ПКМ — сдвиг · КОЛЕСО — масштаб · КЛИК ПО КАРТЕ — перейти · V — от 1-го лица'}
              </div>
            )}
          </div>
        </>
      )}

      {/* стартовый экран */}
      {world && !entered && (
        <div className="absolute inset-0 z-40 flex items-center justify-center" style={{ background: 'linear-gradient(90deg, rgba(8,9,5,0.92) 0%, rgba(8,9,5,0.7) 45%, rgba(8,9,5,0.1) 100%)' }}>
          <div className="w-full max-w-2xl px-8 sm:px-16 sm:pr-0 sm:mr-auto">
            <div className="font-mil mb-3 flex items-center gap-3 text-[11px] tracking-[0.35em] text-[#ff7a5c]">
              <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-[#ff5a3c]" /> ДОСТУП РАЗРЕШЁН · ЗОНА БОЕВЫХ ДЕЙСТВИЙ
            </div>
            <h1 className="font-stencil text-5xl leading-[0.95] text-[#e9dfae] sm:text-7xl">
              ПЕПЕЛЬНЫЙ
              <br />
              <span className="text-[#ffb13b]">КВАРТАЛ</span>
            </h1>
            <p className="font-mil mt-5 max-w-md text-[13px] leading-relaxed text-[#b7b190]">
              3D-карта разрушенного города. Обугленные коробки зданий, подбитые танки, сожжённые машины, баррикады, воронки и дым над руинами. Ходите по улицам от первого лица или осмотрите сектор сверху.
            </p>
            <div className="font-mil mt-6 grid max-w-md grid-cols-4 gap-2 text-center">
              {[
                ['ТАНКИ', world.map.stats.tanks],
                ['МАШИНЫ', world.map.stats.cars],
                ['ЗДАНИЯ', world.map.stats.buildings],
                ['ОЧАГИ', world.map.stats.fires],
              ].map(([l, v]) => (
                <div key={l} className="border border-[#4a5033] bg-black/40 py-2">
                  <div className="font-stencil text-2xl text-[#ffb13b]">{v}</div>
                  <div className="text-[9px] tracking-[0.2em] text-[#8b8a6c]">{l}</div>
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <button onClick={() => enter('fps')} className="font-stencil border-2 border-[#ffb13b] bg-[#ffb13b] px-7 py-3 text-lg tracking-[0.2em] text-[#14110a] transition hover:bg-transparent hover:text-[#ffb13b]">
                ВОЙТИ В ЗОНУ
              </button>
              <button onClick={() => enter('orbit')} className="font-stencil border-2 border-[#5b6240] px-7 py-3 text-lg tracking-[0.2em] text-[#c9c19a] transition hover:border-[#ffb13b] hover:text-[#ffb13b]">
                ОБЗОР СВЕРХУ
              </button>
            </div>
            <div className="font-mil mt-5 text-[10px] tracking-wider text-[#6f6e55]">Рекомендуется со звуком · WASD + мышь · Esc — освободить курсор</div>
          </div>
        </div>
      )}
    </div>
  );
}

const PX = 4; // пикселей на градус
const NAMES: Record<number, string> = { 0: 'С', 45: 'СВ', 90: 'В', 135: 'ЮВ', 180: 'Ю', 225: 'ЮЗ', 270: 'З', 315: 'СЗ' };

export default function Compass({ yaw }: { yaw: number }) {
  const heading = (((-yaw * 180) / Math.PI) % 360 + 360) % 360;
  const ticks: { deg: number; x: number }[] = [];
  const base = Math.round(heading / 5) * 5;
  for (let d = -70; d <= 70; d += 5) {
    const deg = base + d;
    ticks.push({ deg: ((deg % 360) + 360) % 360, x: deg - heading });
  }
  return (
    <div className="relative h-11 w-[440px] max-w-[90vw] overflow-hidden border-y border-[#5b6240] bg-black/45 backdrop-blur-[2px]" style={{ maskImage: 'linear-gradient(90deg, transparent, #000 18%, #000 82%, transparent)' }}>
      {ticks.map((t) => {
        const major = t.deg % 45 === 0;
        const mid = t.deg % 15 === 0;
        return (
          <div key={t.x} className="absolute top-0 flex -translate-x-1/2 flex-col items-center" style={{ left: `calc(50% + ${t.x * PX}px)` }}>
            <div className={major ? 'h-3 w-[2px] bg-[#ffb13b]' : mid ? 'h-2 w-px bg-[#c9c19a]' : 'h-1 w-px bg-[#8b8a6c]'} />
            {major ? (
              <span className="font-stencil mt-0.5 text-[13px] leading-none text-[#ffb13b]">{NAMES[t.deg]}</span>
            ) : mid ? (
              <span className="font-mil mt-1 text-[9px] leading-none text-[#c9c19a]">{t.deg}</span>
            ) : null}
          </div>
        );
      })}
      <div className="absolute bottom-0 left-1/2 h-0 w-0 -translate-x-1/2 border-x-[5px] border-b-[7px] border-x-transparent border-b-[#ff5a3c]" />
    </div>
  );
}

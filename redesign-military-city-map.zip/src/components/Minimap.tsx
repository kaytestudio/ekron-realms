import { useEffect, useRef } from 'react';
import { POIS } from '../world/layout';
import type { WorldHandle } from '../world/createWorld';

const S = 232;
const R = 140; // половина охвата карты в метрах
const k = S / (R * 2);
const W2M = (v: number) => (v + R) * k;

function drawStatic(world: WorldHandle) {
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const g = c.getContext('2d')!;
  g.fillStyle = '#06100a';
  g.fillRect(0, 0, S, S);

  // граница города
  g.fillStyle = '#0b1c10';
  const h = world.map.half;
  g.fillRect(W2M(-h), W2M(-h), h * 2 * k, h * 2 * k);

  // улицы (светлее) — рисуем как сетку
  g.strokeStyle = 'rgba(70,120,70,0.14)';
  g.lineWidth = 16 * k;
  for (const s of [-120, -72, -24, 24, 72, 120]) {
    g.beginPath();
    g.moveTo(W2M(s), W2M(-h));
    g.lineTo(W2M(s), W2M(h));
    g.moveTo(W2M(-h), W2M(s));
    g.lineTo(W2M(h), W2M(s));
    g.stroke();
  }
  // координатная сетка
  g.strokeStyle = 'rgba(90,160,90,0.22)';
  g.lineWidth = 1;
  for (let v = -144; v <= 144; v += 24) {
    g.beginPath();
    g.moveTo(Math.round(W2M(v)) + 0.5, 0);
    g.lineTo(Math.round(W2M(v)) + 0.5, S);
    g.moveTo(0, Math.round(W2M(v)) + 0.5);
    g.lineTo(S, Math.round(W2M(v)) + 0.5);
    g.stroke();
  }
  // воронки
  g.strokeStyle = '#b48a2c';
  g.setLineDash([2, 2]);
  g.lineWidth = 1;
  for (const cr of world.map.craters) {
    g.beginPath();
    g.arc(W2M(cr.x), W2M(cr.z), Math.max(2, cr.r * k), 0, 7);
    g.stroke();
  }
  g.setLineDash([]);
  // здания
  for (const b of world.map.buildings) {
    const dm = Math.min(1, b.damage);
    const r = Math.round(70 - dm * 40);
    const gr = Math.round(150 - dm * 85);
    g.fillStyle = `rgb(${r},${gr},${Math.round(80 - dm * 40)})`;
    g.fillRect(W2M(b.x - b.w / 2), W2M(b.z - b.d / 2), b.w * k, b.d * k);
    g.strokeStyle = 'rgba(160,220,150,0.5)';
    g.strokeRect(W2M(b.x - b.w / 2) + 0.5, W2M(b.z - b.d / 2) + 0.5, b.w * k, b.d * k);
  }
  // техника
  for (const v of world.map.vehicles) {
    g.save();
    g.translate(W2M(v.x), W2M(v.z));
    g.rotate(-v.rot);
    if (v.kind === 'tank') {
      g.fillStyle = '#ffb13b';
      g.fillRect(-2.5, -3.5, 5, 7);
      g.fillStyle = '#2b1c05';
      g.fillRect(-0.7, -5.5, 1.4, 4);
    } else if (v.kind === 'car') {
      g.fillStyle = '#9ac28f';
      g.fillRect(-1.2, -2, 2.4, 4);
    } else {
      g.fillStyle = '#d6c98a';
      g.fillRect(-1.8, -4, 3.6, 8);
    }
    g.restore();
  }
  return c;
}

export default function Minimap({ world, visible }: { world: WorldHandle; visible: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current!;
    const g = canvas.getContext('2d')!;
    const base = drawStatic(world);
    let raf = 0;
    const draw = (t: number) => {
      raf = requestAnimationFrame(draw);
      if (!visible) return;
      g.drawImage(base, 0, 0);
      const time = t / 1000;
      // очаги пожаров
      for (const f of world.map.fires) {
        const a = 0.5 + 0.5 * Math.sin(time * 4 + f.x);
        g.fillStyle = `rgba(255,70,40,${0.55 + a * 0.45})`;
        g.beginPath();
        g.arc(W2M(f.x), W2M(f.z), 1.8 + a * 0.8, 0, 7);
        g.fill();
      }
      // точки интереса
      g.font = '9px "Share Tech Mono", monospace';
      POIS.slice(1).forEach((p, i) => {
        const x = W2M(p.x);
        const y = W2M(p.z);
        g.strokeStyle = '#e8d27a';
        g.lineWidth = 1;
        g.strokeRect(x - 4, y - 4, 8, 8);
        g.fillStyle = '#e8d27a';
        g.fillText(String(i + 2), x + 6, y + 3);
      });
      // сканирующая линия
      const sy = (time * 40) % S;
      const grad = g.createLinearGradient(0, sy - 18, 0, sy);
      grad.addColorStop(0, 'rgba(120,255,140,0)');
      grad.addColorStop(1, 'rgba(120,255,140,0.18)');
      g.fillStyle = grad;
      g.fillRect(0, sy - 18, S, 18);
      // игрок
      const st = world.state;
      const px = W2M(st.x);
      const py = W2M(st.z);
      g.save();
      g.translate(px, py);
      g.rotate(-st.yaw);
      g.fillStyle = 'rgba(255,255,200,0.14)';
      g.beginPath();
      g.moveTo(0, 0);
      g.arc(0, 0, 38, -Math.PI / 2 - 0.6, -Math.PI / 2 + 0.6);
      g.closePath();
      g.fill();
      g.fillStyle = '#f4f0b8';
      g.strokeStyle = '#000';
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(0, -6);
      g.lineTo(4.5, 5);
      g.lineTo(0, 2.5);
      g.lineTo(-4.5, 5);
      g.closePath();
      g.fill();
      g.stroke();
      g.restore();
      // N
      g.fillStyle = '#9fe8a0';
      g.font = 'bold 11px "Share Tech Mono", monospace';
      g.fillText('С', S / 2 - 4, 11);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [world, visible]);

  const click = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width) * S;
    const y = ((e.clientY - r.top) / r.height) * S;
    world.teleport(x / k - R, y / k - R);
  };

  return <canvas ref={ref} width={S} height={S} onClick={click} className="block cursor-crosshair" style={{ width: S, height: S, display: visible ? 'block' : 'none' }} />;
}

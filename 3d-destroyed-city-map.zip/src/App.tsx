import { useCallback, useEffect, useRef, useState } from "react";
import { CityView, type Mode, type ViewStats, type Weather } from "./city/view";
import { cityExtent, type CityData } from "./city/generateCity";
import { cityJSON, downloadBlob, exportGLB, exportSourcesZip } from "./city/exporters";
import { GODOT_SNIPPET, LIBGDX_SNIPPET, UNITY_LOADER } from "./city/docs";
import { HoldButton, Joystick } from "./components/Joystick";
import { Minimap } from "./components/Minimap";

const SIZES = [
  { n: 8, label: "Малый" },
  { n: 12, label: "Средний" },
  { n: 16, label: "Большой" },
  { n: 24, label: "Огромный" },
];
const WEATHERS: { id: Weather; label: string; icon: string }[] = [
  { id: "dusk", label: "Закат", icon: "🌇" },
  { id: "overcast", label: "Пасмурно", icon: "☁️" },
  { id: "night", label: "Ночь", icon: "🌙" },
];
const MODES: { id: Mode; label: string; icon: string }[] = [
  { id: "orbit", label: "Обзор", icon: "🛰️" },
  { id: "walk", label: "Пешком", icon: "🚶" },
  { id: "fly", label: "Полёт", icon: "🕊️" },
];

const isTouch = typeof window !== "undefined" && (("ontouchstart" in window) || window.matchMedia("(pointer:coarse)").matches);

export default function App() {
  const host = useRef<HTMLDivElement>(null);
  const [view, setView] = useState<CityView | null>(null);
  const [city, setCity] = useState<CityData | null>(null);
  const [loading, setLoading] = useState("Строим город…");
  const [stats, setStats] = useState<ViewStats>({ fps: 0, calls: 0, triangles: 0 });
  const [mode, setModeState] = useState<Mode>("orbit");
  const [weather, setWeatherState] = useState<Weather>("dusk");
  const [size, setSize] = useState(isTouch ? 12 : 16);
  const [destruction, setDestruction] = useState(65);
  const [seed, setSeed] = useState(2025);
  const [panel, setPanel] = useState(!isTouch);
  const [help, setHelp] = useState(false);
  const [busy, setBusy] = useState("");
  const [tab, setTab] = useState<"unity" | "godot" | "libgdx">("unity");

  useEffect(() => {
    const v = new CityView(host.current!);
    v.onStats = setStats;
    setView(v);
    return () => v.dispose();
  }, []);

  const build = useCallback(
    (v: CityView, n: number, s: number, d: number) => {
      setLoading("Строим город…");
      setTimeout(() => {
        const t0 = performance.now();
        const c = v.generate({ seed: s, blocks: n, destruction: d / 100 });
        console.log("city generated in", Math.round(performance.now() - t0), "ms");
        setCity(c);
        setModeState("orbit");
        setLoading("");
      }, 60);
    },
    []
  );

  useEffect(() => {
    if (view) build(view, size, seed, destruction);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view]);

  const regenerate = (newSeed = seed) => {
    if (view) build(view, size, newSeed, destruction);
  };
  const randomSeed = () => {
    const s = Math.floor(Math.random() * 99999);
    setSeed(s);
    regenerate(s);
  };
  const changeMode = (m: Mode) => {
    view?.setMode(m);
    setModeState(m);
  };
  const changeWeather = (w: Weather) => {
    view?.applyWeather(w);
    setWeatherState(w);
  };

  const run = async (name: string, fn: () => Promise<void> | void) => {
    setBusy(name);
    await new Promise((r) => setTimeout(r, 30));
    try {
      await fn();
    } catch (e) {
      console.error(e);
      alert("Ошибка экспорта: " + (e as Error).message);
    }
    setBusy("");
  };

  const km = (cityExtent(size) / 1000).toFixed(1);

  return (
    <div className="fixed inset-0 overflow-hidden bg-black font-sans text-white select-none">
      <div ref={host} className="absolute inset-0" />

      {/* Загрузка */}
      {loading && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center gap-4 bg-black/80 backdrop-blur-sm">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-amber-400/30 border-t-amber-400" />
          <div className="text-lg font-semibold tracking-wide">{loading}</div>
          <div className="text-sm text-white/60">Улицы, руины, воронки, пожары…</div>
        </div>
      )}

      {/* Шапка */}
      <div className="pointer-events-none absolute left-3 top-3 z-10 max-w-[70%]">
        <div className="pointer-events-auto inline-block rounded-xl border border-white/15 bg-black/50 px-4 py-2.5 shadow-xl backdrop-blur-md">
          <div className="flex items-center gap-2">
            <span className="text-xl">🏚️</span>
            <div>
              <h1 className="text-sm font-bold uppercase tracking-[0.18em] text-amber-300 sm:text-base">Ruined City</h1>
              <p className="text-[11px] text-white/60">Процедурная карта «Разрушенный город»</p>
            </div>
          </div>
          {city && (
            <div className="mt-2 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-white/70">
              <span>🏢 {city.stats.buildings}</span>
              <span>🔥 {city.stats.fires}</span>
              <span>💥 {city.stats.craters}</span>
              <span>▲ {(stats.triangles / 1000).toFixed(0)}k / {(city.stats.triangles / 1000).toFixed(0)}k</span>
              <span>DC {stats.calls}</span>
              <span className={stats.fps >= 45 ? "text-emerald-300" : stats.fps >= 28 ? "text-amber-300" : "text-red-400"}>{stats.fps} FPS</span>
            </div>
          )}
        </div>
      </div>

      {/* Кнопки справа сверху */}
      <div className="absolute right-3 top-3 z-20 flex gap-2">
        <button
          onClick={() => setHelp(true)}
          className="rounded-xl border border-white/15 bg-black/50 px-3 py-2 text-sm shadow-xl backdrop-blur-md hover:bg-black/70"
        >
          📱 Android
        </button>
        <button
          onClick={() => setPanel((p) => !p)}
          className="rounded-xl border border-amber-300/40 bg-amber-500/80 px-3 py-2 text-sm font-semibold text-black shadow-xl hover:bg-amber-400"
        >
          {panel ? "✕ Скрыть" : "⚙ Карта"}
        </button>
      </div>

      {/* Панель настроек */}
      {panel && (
        <div className="absolute right-3 top-16 z-20 max-h-[calc(100%-5rem)] w-[min(20rem,calc(100%-1.5rem))] overflow-y-auto rounded-2xl border border-white/15 bg-neutral-950/85 p-4 shadow-2xl backdrop-blur-lg">
          <Label>Размер карты</Label>
          <div className="grid grid-cols-4 gap-1.5">
            {SIZES.map((s) => (
              <button
                key={s.n}
                onClick={() => setSize(s.n)}
                className={`rounded-lg border px-1 py-1.5 text-xs transition ${
                  size === s.n ? "border-amber-300 bg-amber-400/20 text-amber-200" : "border-white/10 bg-white/5 hover:bg-white/10"
                }`}
              >
                <div className="font-semibold">{s.label}</div>
                <div className="text-[10px] opacity-60">{s.n}×{s.n}</div>
              </button>
            ))}
          </div>
          <p className="mt-1 text-[11px] text-white/50">
            ≈ {km} × {km} км · {size * size} кварталов
          </p>

          <Label>Разрушения: {destruction}%</Label>
          <input
            type="range"
            min={0}
            max={100}
            value={destruction}
            onChange={(e) => setDestruction(+e.target.value)}
            className="w-full accent-amber-400"
          />

          <Label>Сид (число карты)</Label>
          <div className="flex gap-2">
            <input
              type="number"
              value={seed}
              onChange={(e) => setSeed(Math.abs(Math.floor(+e.target.value || 0)))}
              className="w-full rounded-lg border border-white/15 bg-black/50 px-3 py-1.5 text-sm outline-none focus:border-amber-300"
            />
            <button onClick={randomSeed} className="rounded-lg border border-white/15 bg-white/10 px-3 hover:bg-white/20" title="Случайный сид">
              🎲
            </button>
          </div>

          <button
            onClick={() => regenerate()}
            className="mt-3 w-full rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 py-2.5 text-sm font-bold text-black shadow-lg transition hover:brightness-110"
          >
            Сгенерировать город
          </button>

          <Label>Погода / время</Label>
          <div className="grid grid-cols-3 gap-1.5">
            {WEATHERS.map((w) => (
              <button
                key={w.id}
                onClick={() => changeWeather(w.id)}
                className={`rounded-lg border py-1.5 text-xs transition ${
                  weather === w.id ? "border-amber-300 bg-amber-400/20 text-amber-200" : "border-white/10 bg-white/5 hover:bg-white/10"
                }`}
              >
                <div className="text-base">{w.icon}</div>
                {w.label}
              </button>
            ))}
          </div>

          <Label>Экспорт для игры</Label>
          <div className="space-y-1.5">
            <ExportBtn
              busy={busy === "glb"}
              disabled={!city || !!busy}
              onClick={() =>
                run("glb", async () => {
                  const blob = await exportGLB(city!);
                  downloadBlob("ruined_city.glb", blob);
                })
              }
              title="⬇ Скачать GLB (3D-модель карты)"
              sub={`Unity · Godot · Unreal · libGDX · ≈ ${city ? Math.round((city.stats.vertices * 36) / 1048576) : 0} МБ`}
            />
            <ExportBtn
              busy={busy === "json"}
              disabled={!city || !!busy}
              onClick={() =>
                run("json", () => downloadBlob("ruined_city.json", new Blob([cityJSON(city!)], { type: "application/json" })))
              }
              title="⬇ Скачать JSON (коллайдеры, спавны)"
              sub="здания · точки спавна · пожары · воронки"
            />
            <ExportBtn
              busy={busy === "zip"}
              disabled={!!busy}
              onClick={() => run("zip", async () => downloadBlob("ruined-city-sources.zip", await exportSourcesZip()))}
              title="⬇ Скачать исходники (.zip)"
              sub="весь код генератора + примеры для движков"
            />
          </div>
        </div>
      )}

      {/* Режимы камеры */}
      <div className="absolute bottom-3 left-1/2 z-10 flex -translate-x-1/2 gap-1 rounded-2xl border border-white/15 bg-black/55 p-1 shadow-xl backdrop-blur-md">
        {MODES.map((m) => (
          <button
            key={m.id}
            onClick={() => changeMode(m.id)}
            className={`rounded-xl px-3 py-2 text-xs font-semibold transition sm:px-4 sm:text-sm ${
              mode === m.id ? "bg-amber-400 text-black" : "text-white/80 hover:bg-white/10"
            }`}
          >
            <span className="mr-1">{m.icon}</span>
            {m.label}
          </button>
        ))}
      </div>

      {/* Мини-карта */}
      <div className="absolute bottom-16 right-3 z-10 sm:bottom-3">
        <Minimap city={city} view={view} />
      </div>

      {/* Управление: подсказка / джойстик */}
      {isTouch ? (
        mode !== "orbit" && (
          <>
            <div className="absolute bottom-20 left-5 z-10">
              <Joystick view={view} />
            </div>
            <div className="absolute bottom-24 right-5 z-10 hidden" />
            <div className="absolute bottom-52 left-5 z-10 flex gap-2">
              <HoldButton label="⚡" onChange={(v) => view && (view.virt.sprint = v)} />
              {mode === "fly" && (
                <>
                  <HoldButton label="▲" onChange={(v) => view && (view.virt.up = v)} />
                  <HoldButton label="▼" onChange={(v) => view && (view.virt.down = v)} />
                </>
              )}
            </div>
          </>
        )
      ) : (
        <div className="pointer-events-none absolute bottom-3 left-3 z-10 hidden max-w-xs rounded-xl border border-white/10 bg-black/45 px-3 py-2 text-[11px] leading-relaxed text-white/70 backdrop-blur-md md:block">
          {mode === "orbit" ? (
            <>🖱 Тяните мышью — вращение · колесо — масштаб · клик по мини-карте — телепорт</>
          ) : (
            <>
              <b className="text-amber-300">WASD</b> — движение · <b className="text-amber-300">ЛКМ + мышь</b> — осмотр ·{" "}
              <b className="text-amber-300">Shift</b> — бег{mode === "fly" && <> · <b className="text-amber-300">Q/E</b> — вниз/вверх · колесо — скорость</>}
            </>
          )}
        </div>
      )}
      {isTouch && mode === "orbit" && (
        <div className="pointer-events-none absolute bottom-20 left-3 z-10 rounded-xl bg-black/45 px-3 py-2 text-[11px] text-white/70 backdrop-blur-md">
          Тяните — вращение · щипок — масштаб · «Пешком» — прогулка по городу
        </div>
      )}

      {/* Окно «Как подключить к Android» */}
      {help && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 p-3 backdrop-blur-sm" onClick={() => setHelp(false)}>
          <div
            className="flex max-h-full w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-white/15 bg-neutral-950 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-3">
              <h2 className="font-bold text-amber-300">Как использовать карту в Android-игре</h2>
              <button onClick={() => setHelp(false)} className="rounded-lg px-2 py-1 hover:bg-white/10">
                ✕
              </button>
            </div>
            <div className="space-y-3 overflow-y-auto p-5 text-sm text-white/80 select-text">
              <ol className="list-decimal space-y-1 pl-5">
                <li>Настройте размер, разрушения и сид — нажмите «Сгенерировать город».</li>
                <li>
                  В панели «Экспорт» скачайте <b>GLB</b> (геометрия + цвета + текстура окон) и <b>JSON</b> (коллайдеры зданий, спавны).
                </li>
                <li>Скачайте <b>исходники (.zip)</b> — там весь генератор на TypeScript/Three.js и примеры для движков.</li>
                <li>Импортируйте GLB в Unity / Godot / Unreal / libGDX и соберите APK/AAB штатными средствами движка.</li>
              </ol>
              <div className="rounded-lg border border-amber-300/20 bg-amber-400/5 p-3 text-xs text-amber-100/80">
                Оптимизация: геометрия слита в чанки по 200 м и всего 3 материала. Для телефона берите «Средний» (12×12) или «Большой»;
                включайте туман и дальность камеры 400–600 м. Руины на лотах без коллайдеров проходимы — это завалы.
              </div>
              <div className="flex gap-1">
                {(["unity", "godot", "libgdx"] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setTab(t)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-semibold uppercase ${
                      tab === t ? "bg-amber-400 text-black" : "bg-white/10 hover:bg-white/20"
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
              <pre className="max-h-72 overflow-auto rounded-lg border border-white/10 bg-black/60 p-3 text-[11px] leading-relaxed text-emerald-200/90">
                {tab === "unity" ? UNITY_LOADER : tab === "godot" ? GODOT_SNIPPET : LIBGDX_SNIPPET}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <div className="mb-1.5 mt-4 text-[11px] font-semibold uppercase tracking-wider text-white/50">{children}</div>;
}

function ExportBtn({
  title,
  sub,
  onClick,
  disabled,
  busy,
}: {
  title: string;
  sub: string;
  onClick: () => void;
  disabled?: boolean;
  busy?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-left transition hover:bg-white/10 disabled:opacity-50"
    >
      <div className="text-xs font-semibold">{busy ? "⏳ Подготовка файла…" : title}</div>
      <div className="text-[10px] text-white/50">{sub}</div>
    </button>
  );
}

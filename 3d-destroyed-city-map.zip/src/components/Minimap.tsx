import { useEffect, useRef } from "react";
import type { CityData } from "../city/generateCity";
import type { CityView } from "../city/view";

const SIZE = 168;

export function Minimap({ city, view }: { city: CityData | null; view: CityView | null }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const bg = useRef<HTMLCanvasElement | null>(null);

  // статичная подложка
  useEffect(() => {
    if (!city) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const c = document.createElement("canvas");
    c.width = c.height = SIZE * dpr;
    const g = c.getContext("2d")!;
    g.scale(dpr, dpr);
    const k = SIZE / (city.half * 2);
    const X = (v: number) => (v + city.half) * k;
    g.fillStyle = "#1d1b19";
    g.fillRect(0, 0, SIZE, SIZE);
    for (const b of city.blocks) {
      g.fillStyle = b.kind === "park" ? "#3b3d26" : b.kind === "crater" ? "#2f2a25" : "#34312d";
      g.fillRect(X(b.x0), X(b.z0), (b.x1 - b.x0) * k, (b.z1 - b.z0) * k);
    }
    for (const c2 of city.colliders) {
      const t = Math.min(1, c2.h / 90);
      const v = Math.round(80 + t * 110);
      g.fillStyle = `rgb(${v},${v - 6},${v - 14})`;
      g.fillRect(X(c2.x - c2.hw), X(c2.z - c2.hd), Math.max(1, c2.hw * 2 * k), Math.max(1, c2.hd * 2 * k));
    }
    g.fillStyle = "#0c0b0a";
    for (const cr of city.craters) {
      g.beginPath();
      g.arc(X(cr.x), X(cr.z), Math.max(1.5, cr.r * k), 0, Math.PI * 2);
      g.fill();
    }
    g.fillStyle = "#ff7a1a";
    for (const f of city.fires) g.fillRect(X(f.x) - 1, X(f.z) - 1, 2.5, 2.5);
    bg.current = c;
  }, [city]);

  // маркер игрока
  useEffect(() => {
    if (!view || !city) return;
    const cv = ref.current!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = cv.height = SIZE * dpr;
    const g = cv.getContext("2d")!;
    view.onPose = (p) => {
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.clearRect(0, 0, cv.width, cv.height);
      if (bg.current) g.drawImage(bg.current, 0, 0);
      g.scale(dpr, dpr);
      const k = SIZE / (city.half * 2);
      const x = (p.x + city.half) * k;
      const y = (p.z + city.half) * k;
      const dx = -Math.sin(p.yaw);
      const dy = -Math.cos(p.yaw);
      // конус обзора
      g.fillStyle = "rgba(255,220,120,0.25)";
      g.beginPath();
      g.moveTo(x, y);
      const a = Math.atan2(dy, dx);
      g.arc(x, y, 26, a - 0.6, a + 0.6);
      g.closePath();
      g.fill();
      g.fillStyle = "#ffd36b";
      g.strokeStyle = "#000";
      g.lineWidth = 1.5;
      g.beginPath();
      g.arc(x, y, 3.6, 0, Math.PI * 2);
      g.fill();
      g.stroke();
    };
    return () => {
      view.onPose = undefined;
    };
  }, [view, city]);

  return (
    <canvas
      ref={ref}
      style={{ width: SIZE, height: SIZE }}
      className="cursor-crosshair rounded-lg border border-white/25 shadow-xl"
      onPointerDown={(e) => {
        if (!city || !view) return;
        const r = e.currentTarget.getBoundingClientRect();
        const x = ((e.clientX - r.left) / r.width) * city.half * 2 - city.half;
        const z = ((e.clientY - r.top) / r.height) * city.half * 2 - city.half;
        view.teleport(x, z);
      }}
    />
  );
}

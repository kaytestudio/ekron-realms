import { useRef, useState } from "react";
import type { CityView } from "../city/view";

const R = 48;

/** Виртуальный джойстик для сенсорных экранов */
export function Joystick({ view }: { view: CityView | null }) {
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const base = useRef<HTMLDivElement>(null);
  const active = useRef<number | null>(null);

  const upd = (e: React.PointerEvent) => {
    const r = base.current!.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    const l = Math.hypot(dx, dy);
    if (l > R) {
      dx = (dx / l) * R;
      dy = (dy / l) * R;
    }
    setKnob({ x: dx, y: dy });
    if (view) {
      view.joy.x = dx / R;
      view.joy.y = -dy / R;
    }
  };
  const end = () => {
    active.current = null;
    setKnob({ x: 0, y: 0 });
    if (view) {
      view.joy.x = 0;
      view.joy.y = 0;
    }
  };

  return (
    <div
      ref={base}
      className="relative h-36 w-36 select-none rounded-full border border-white/25 bg-black/35 backdrop-blur-sm"
      style={{ touchAction: "none" }}
      onPointerDown={(e) => {
        active.current = e.pointerId;
        (e.target as HTMLElement).setPointerCapture(e.pointerId);
        upd(e);
      }}
      onPointerMove={(e) => active.current === e.pointerId && upd(e)}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 h-16 w-16 rounded-full border border-amber-200/60 bg-amber-400/40 shadow-lg"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
    </div>
  );
}

/** Кнопка с удержанием (вверх/вниз/бег) */
export function HoldButton({
  label,
  onChange,
  className = "",
}: {
  label: string;
  onChange: (v: boolean) => void;
  className?: string;
}) {
  const [on, setOn] = useState(false);
  const set = (v: boolean) => {
    setOn(v);
    onChange(v);
  };
  return (
    <button
      className={`flex h-14 w-14 select-none items-center justify-center rounded-full border text-xl backdrop-blur-sm transition ${
        on ? "border-amber-300 bg-amber-500/60" : "border-white/25 bg-black/40"
      } ${className}`}
      style={{ touchAction: "none" }}
      onPointerDown={(e) => {
        (e.target as HTMLElement).setPointerCapture(e.pointerId);
        set(true);
      }}
      onPointerUp={() => set(false)}
      onPointerCancel={() => set(false)}
    >
      {label}
    </button>
  );
}

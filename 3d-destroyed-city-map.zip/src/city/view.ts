import * as THREE from "three";
import { createMaterials } from "./textures";
import { generateCity, type CityData, type CityOptions } from "./generateCity";

export type Mode = "orbit" | "walk" | "fly";
export type Weather = "dusk" | "overcast" | "night";

interface WeatherPreset {
  top: number;
  horizon: number;
  fog: number;
  near: number;
  far: number;
  sun: number;
  sunI: number;
  sunDir: [number, number, number];
  hemiSky: number;
  hemiGround: number;
  hemiI: number;
  smoke: number;
  exposure: number;
}

const PRESETS: Record<Weather, WeatherPreset> = {
  dusk: {
    top: 0x34456a,
    horizon: 0xe59a63,
    fog: 0xc98d62,
    near: 60,
    far: 800,
    sun: 0xffb272,
    sunI: 2.6,
    sunDir: [-0.8, 0.28, -0.55],
    hemiSky: 0x8da0c8,
    hemiGround: 0x4a3a2e,
    hemiI: 1.0,
    smoke: 0x2b2522,
    exposure: 1.0,
  },
  overcast: {
    top: 0x6f777e,
    horizon: 0xb8bbbb,
    fog: 0xaaadad,
    near: 30,
    far: 650,
    sun: 0xffffff,
    sunI: 1.2,
    sunDir: [0.3, 0.8, 0.4],
    hemiSky: 0xcfd6dc,
    hemiGround: 0x5b5750,
    hemiI: 1.5,
    smoke: 0x3a3836,
    exposure: 1.0,
  },
  night: {
    top: 0x04060c,
    horizon: 0x1c2636,
    fog: 0x0b111a,
    near: 15,
    far: 520,
    sun: 0x7f95c4,
    sunI: 0.9,
    sunDir: [0.5, 0.6, -0.4],
    hemiSky: 0x3a4a73,
    hemiGround: 0x15181f,
    hemiI: 0.9,
    smoke: 0x050505,
    exposure: 1.15,
  },
};

export interface Pose {
  x: number;
  z: number;
  yaw: number;
}
export interface ViewStats {
  fps: number;
  calls: number;
  triangles: number;
}

const SKY_VS = `
varying vec3 vDir;
void main(){
  vDir = normalize(position);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}`;
const SKY_FS = `
uniform vec3 uTop; uniform vec3 uHor; uniform vec3 uSun; uniform vec3 uSunDir;
varying vec3 vDir;
void main(){
  vec3 d = normalize(vDir);
  float h = clamp(d.y, 0.0, 1.0);
  vec3 col = mix(uHor, uTop, pow(h, 0.45));
  float s = max(dot(d, normalize(uSunDir)), 0.0);
  col += uSun * (pow(s, 6.0) * 0.28 + pow(s, 220.0) * 1.6);
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;
const SMOKE_VS = `
uniform float uTime; uniform float uScale;
attribute float aSeed;
varying float vA;
void main(){
  float t = fract(uTime * 0.045 + aSeed);
  vec3 p = position;
  p.y += 3.0 + t * 75.0;
  p.x += t * t * 38.0 + sin(aSeed * 40.0 + uTime * 0.5) * t * 6.0;
  p.z += sin(aSeed * 91.0) * t * 9.0;
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  float size = 6.0 + t * 42.0;
  gl_PointSize = min(size * uScale / max(-mv.z, 1.0), 220.0);
  vA = (1.0 - t) * smoothstep(0.0, 0.08, t) * 0.5;
  gl_Position = projectionMatrix * mv;
}`;
const SMOKE_FS = `
uniform vec3 uColor;
varying float vA;
void main(){
  float d = length(gl_PointCoord - 0.5);
  float a = smoothstep(0.5, 0.05, d) * vA;
  if (a < 0.003) discard;
  gl_FragColor = vec4(uColor, a);
  #include <colorspace_fragment>
}`;

export class CityView {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(72, 1, 0.4, 4500);
  mats = createMaterials();
  city: CityData | null = null;

  mode: Mode = "orbit";
  weather: Weather = "dusk";
  onPose?: (p: Pose) => void;
  onStats?: (s: ViewStats) => void;

  private sky: THREE.Mesh;
  private skyMat: THREE.ShaderMaterial;
  private hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 1);
  private sun = new THREE.DirectionalLight(0xffffff, 1);
  private fog = new THREE.Fog(0x000000, 50, 900);
  private smoke: THREE.Points | null = null;
  private smokeMat: THREE.ShaderMaterial;

  // положение камеры
  private pos = new THREE.Vector3(0, 1.7, 0);
  private yaw = 0;
  private pitch = 0;
  private orbitYaw = 0.6;
  private orbitPitch = 0.55;
  private orbitDist = 900;
  private autoRotate = true;

  private keys = new Set<string>();
  joy = { x: 0, y: 0 };
  virt = { up: false, down: false, sprint: false };
  private pointers = new Map<number, { x: number; y: number }>();
  private pinch = 0;
  private raf = 0;
  private last = performance.now();
  private time = 0;
  private bob = 0;
  private frames = 0;
  private fpsT = 0;
  private poseT = 0;
  private cullT = 0;
  private flySpeed = 1;
  private disposers: (() => void)[] = [];

  constructor(private container: HTMLElement) {
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    const cv = this.renderer.domElement;
    cv.style.touchAction = "none";
    cv.style.display = "block";
    cv.style.width = "100%";
    cv.style.height = "100%";
    container.appendChild(cv);

    this.camera.rotation.order = "YXZ";
    this.scene.fog = this.fog;
    this.scene.add(this.hemi, this.sun);

    this.skyMat = new THREE.ShaderMaterial({
      uniforms: {
        uTop: { value: new THREE.Color() },
        uHor: { value: new THREE.Color() },
        uSun: { value: new THREE.Color() },
        uSunDir: { value: new THREE.Vector3(0, 1, 0) },
      },
      vertexShader: SKY_VS,
      fragmentShader: SKY_FS,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(3500, 32, 16), this.skyMat);
    this.sky.renderOrder = -10;
    this.sky.frustumCulled = false;
    this.scene.add(this.sky);

    this.smokeMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uScale: { value: 500 }, uColor: { value: new THREE.Color(0x222222) } },
      vertexShader: SMOKE_VS,
      fragmentShader: SMOKE_FS,
      transparent: true,
      depthWrite: false,
    });

    this.applyWeather(this.weather);
    this.resize();
    this.bindInput();
    const ro = new ResizeObserver(() => this.resize());
    ro.observe(container);
    this.disposers.push(() => ro.disconnect());
    this.loop();
  }

  /* ----------------------------- город ----------------------------- */

  generate(opts: CityOptions): CityData {
    if (this.city) {
      this.scene.remove(this.city.group);
      this.city.group.traverse((o) => {
        if ((o as THREE.Mesh).geometry) (o as THREE.Mesh).geometry.dispose();
      });
    }
    if (this.smoke) {
      this.scene.remove(this.smoke);
      this.smoke.geometry.dispose();
      this.smoke = null;
    }
    const city = generateCity(opts, this.mats);
    this.city = city;
    this.scene.add(city.group);

    // дым над пожарами
    const per = 26;
    const n = city.fires.length * per;
    if (n > 0) {
      const p = new Float32Array(n * 3);
      const s = new Float32Array(n);
      city.fires.forEach((f, i) => {
        for (let k = 0; k < per; k++) {
          const j = i * per + k;
          p[j * 3] = f.x;
          p[j * 3 + 1] = f.y;
          p[j * 3 + 2] = f.z;
          s[j] = (k + Math.random() * 0.8) / per;
        }
      });
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.BufferAttribute(p, 3));
      g.setAttribute("aSeed", new THREE.BufferAttribute(s, 1));
      this.smoke = new THREE.Points(g, this.smokeMat);
      this.smoke.frustumCulled = false;
      this.smoke.renderOrder = 5;
      this.scene.add(this.smoke);
    }

    this.orbitDist = city.half * 1.5;
    this.orbitYaw = 0.6;
    this.orbitPitch = 0.55;
    this.autoRotate = true;
    this.setMode("orbit");
    return city;
  }

  /* ----------------------------- погода ----------------------------- */

  applyWeather(w: Weather) {
    this.weather = w;
    const p = PRESETS[w];
    const u = this.skyMat.uniforms;
    u.uTop.value.set(p.top);
    u.uHor.value.set(p.horizon);
    u.uSun.value.set(p.sun);
    u.uSunDir.value.set(...p.sunDir).normalize();
    this.fog.color.set(p.fog);
    this.hemi.color.set(p.hemiSky);
    this.hemi.groundColor.set(p.hemiGround);
    this.hemi.intensity = p.hemiI;
    this.sun.color.set(p.sun);
    this.sun.intensity = p.sunI;
    this.sun.position.set(...p.sunDir).normalize().multiplyScalar(100);
    this.smokeMat.uniforms.uColor.value.set(p.smoke);
    this.renderer.toneMappingExposure = p.exposure;
  }

  /* ----------------------------- режимы ----------------------------- */

  setMode(m: Mode) {
    const prev = this.mode;
    this.mode = m;
    if (m === "walk") {
      if (prev === "orbit" || this.hitsAny(this.pos.x, this.pos.z)) {
        const sp = this.city?.spawns[Math.floor(Math.random() * (this.city?.spawns.length || 1))];
        if (sp) {
          this.pos.set(sp.x, 1.7, sp.z);
          this.yaw = sp.yaw;
        } else this.pos.set(0, 1.7, 0);
        this.pitch = 0;
      }
      this.pos.y = 1.7;
    } else if (m === "fly") {
      if (prev === "orbit") {
        this.yaw = this.camera.rotation.y;
        this.pitch = this.camera.rotation.x;
        this.pos.copy(this.camera.position);
      } else this.pos.y = Math.max(this.pos.y, 25);
    }
  }

  teleport(x: number, z: number) {
    if (this.mode === "orbit") {
      this.pos.set(x, 60, z);
      this.pitch = -0.4;
      this.setMode("fly");
    }
    const lim = (this.city?.half ?? 500) + 40;
    this.pos.x = Math.max(-lim, Math.min(lim, x));
    this.pos.z = Math.max(-lim, Math.min(lim, z));
    if (this.mode === "walk") {
      const r = this.resolve(this.pos.x, this.pos.z);
      this.pos.x = r[0];
      this.pos.z = r[1];
    }
  }

  setKeyboardFocus(_: boolean) {
    /* зарезервировано */
  }

  /* ----------------------------- коллизии ----------------------------- */

  private hitsAny(x: number, z: number, r = 0.6) {
    const cs = this.city?.colliders;
    if (!cs) return false;
    for (let i = 0; i < cs.length; i++) {
      const c = cs[i];
      if (Math.abs(x - c.x) < c.hw + r && Math.abs(z - c.z) < c.hd + r) return true;
    }
    return false;
  }

  private resolve(x: number, z: number, r = 0.6): [number, number] {
    const cs = this.city?.colliders;
    if (!cs) return [x, z];
    for (let i = 0; i < cs.length; i++) {
      const c = cs[i];
      const dx = x - c.x;
      const dz = z - c.z;
      const px = c.hw + r - Math.abs(dx);
      const pz = c.hd + r - Math.abs(dz);
      if (px > 0 && pz > 0) {
        if (px < pz) x += Math.sign(dx || 1) * px;
        else z += Math.sign(dz || 1) * pz;
      }
    }
    return [x, z];
  }

  /* ----------------------------- ввод ----------------------------- */

  private bindInput() {
    const cv = this.renderer.domElement;
    const typing = (e: Event) => {
      const t = e.target as HTMLElement | null;
      return !!t && ["INPUT", "SELECT", "TEXTAREA"].includes(t.tagName);
    };
    const kd = (e: KeyboardEvent) => {
      if (typing(e)) return;
      this.keys.add(e.code);
      if (e.code === "Space") e.preventDefault();
    };
    const ku = (e: KeyboardEvent) => this.keys.delete(e.code);
    const blur = () => this.keys.clear();
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    window.addEventListener("blur", blur);

    const down = (e: PointerEvent) => {
      cv.setPointerCapture(e.pointerId);
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      this.autoRotate = false;
      if (this.pointers.size === 2) this.pinch = this.pinchDist();
    };
    const move = (e: PointerEvent) => {
      const p = this.pointers.get(e.pointerId);
      if (!p) return;
      const dx = e.clientX - p.x;
      const dy = e.clientY - p.y;
      p.x = e.clientX;
      p.y = e.clientY;
      if (this.pointers.size >= 2) {
        const d = this.pinchDist();
        if (this.mode === "orbit") this.orbitDist = clamp(this.orbitDist * (this.pinch / Math.max(d, 1)), 40, 3200);
        this.pinch = d;
        return;
      }
      const k = e.pointerType === "touch" ? 0.0055 : 0.0035;
      if (this.mode === "orbit") {
        this.orbitYaw -= dx * 0.005;
        this.orbitPitch = clamp(this.orbitPitch + dy * 0.004, 0.06, 1.5);
      } else {
        this.yaw -= dx * k;
        this.pitch = clamp(this.pitch - dy * k, -1.5, 1.5);
      }
    };
    const up = (e: PointerEvent) => {
      this.pointers.delete(e.pointerId);
      if (this.pointers.size < 2) this.pinch = 0;
    };
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      if (this.mode === "orbit") this.orbitDist = clamp(this.orbitDist * (1 + e.deltaY * 0.001), 40, 3200);
      else this.flySpeed = clamp(this.flySpeed * (1 - e.deltaY * 0.001), 0.2, 8);
    };
    cv.addEventListener("pointerdown", down);
    cv.addEventListener("pointermove", move);
    cv.addEventListener("pointerup", up);
    cv.addEventListener("pointercancel", up);
    cv.addEventListener("wheel", wheel, { passive: false });
    this.disposers.push(() => {
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      window.removeEventListener("blur", blur);
      cv.removeEventListener("pointerdown", down);
      cv.removeEventListener("pointermove", move);
      cv.removeEventListener("pointerup", up);
      cv.removeEventListener("pointercancel", up);
      cv.removeEventListener("wheel", wheel);
    });
  }

  private pinchDist() {
    const a = [...this.pointers.values()];
    return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y);
  }

  /* ----------------------------- цикл ----------------------------- */

  resize() {
    const w = this.container.clientWidth || 1;
    const h = this.container.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    const bufH = this.renderer.domElement.height;
    this.smokeMat.uniforms.uScale.value = bufH / (2 * Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2)));
  }

  private loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    this.time += dt;
    this.update(dt);
    this.smokeMat.uniforms.uTime.value = this.time;
    this.sky.position.copy(this.camera.position);
    this.renderer.render(this.scene, this.camera);

    this.frames++;
    this.fpsT += dt;
    if (this.fpsT >= 0.6) {
      this.onStats?.({
        fps: Math.round(this.frames / this.fpsT),
        calls: this.renderer.info.render.calls,
        triangles: this.renderer.info.render.triangles,
      });
      this.frames = 0;
      this.fpsT = 0;
    }
  };

  private update(dt: number) {
    const k = this.keys;
    const preset = PRESETS[this.weather];
    const cam = this.camera;

    if (this.mode === "orbit") {
      if (this.autoRotate) this.orbitYaw += dt * 0.04;
      const d = this.orbitDist;
      const cp = Math.cos(this.orbitPitch);
      cam.position.set(Math.sin(this.orbitYaw) * cp * d, Math.sin(this.orbitPitch) * d + 4, Math.cos(this.orbitYaw) * cp * d);
      cam.lookAt(0, 20, 0);
      this.fog.near = d * 0.7;
      this.fog.far = d * 2.6 + 600;
    } else {
      let ix = (k.has("KeyD") || k.has("ArrowRight") ? 1 : 0) - (k.has("KeyA") || k.has("ArrowLeft") ? 1 : 0) + this.joy.x;
      let iz = (k.has("KeyW") || k.has("ArrowUp") ? 1 : 0) - (k.has("KeyS") || k.has("ArrowDown") ? 1 : 0) + this.joy.y;
      const len = Math.hypot(ix, iz);
      if (len > 1) {
        ix /= len;
        iz /= len;
      }
      const sprint = k.has("ShiftLeft") || k.has("ShiftRight") || this.virt.sprint;
      const sy = Math.sin(this.yaw);
      const cy = Math.cos(this.yaw);
      if (this.mode === "walk") {
        const speed = sprint ? 9 : 4.5;
        const vx = (-sy * iz + cy * ix) * speed * dt;
        const vz = (-cy * iz - sy * ix) * speed * dt;
        let nx = this.pos.x + vx;
        if (this.hitsAny(nx, this.pos.z)) nx = this.pos.x;
        let nz = this.pos.z + vz;
        if (this.hitsAny(nx, nz)) nz = this.pos.z;
        this.pos.x = nx;
        this.pos.z = nz;
        const moving = Math.hypot(ix, iz) > 0.05;
        this.bob += moving ? dt * (sprint ? 12 : 8) : 0;
        this.pos.y = 1.7 + (moving ? Math.sin(this.bob) * 0.05 : 0);
      } else {
        const speed = 45 * this.flySpeed * (sprint ? 3.5 : 1);
        const cp = Math.cos(this.pitch);
        const fx = -sy * cp;
        const fy = Math.sin(this.pitch);
        const fz = -cy * cp;
        this.pos.x += (fx * iz + cy * ix) * speed * dt;
        this.pos.y += fy * iz * speed * dt;
        this.pos.z += (fz * iz - sy * ix) * speed * dt;
        const up = (k.has("KeyE") || k.has("Space") || this.virt.up ? 1 : 0) - (k.has("KeyQ") || k.has("KeyC") || this.virt.down ? 1 : 0);
        this.pos.y = clamp(this.pos.y + up * speed * 0.7 * dt, 2, 900);
      }
      const lim = (this.city?.half ?? 500) + 60;
      this.pos.x = clamp(this.pos.x, -lim, lim);
      this.pos.z = clamp(this.pos.z, -lim, lim);
      cam.position.copy(this.pos);
      cam.rotation.set(this.pitch, this.yaw, 0);
      this.fog.near = preset.near;
      this.fog.far = preset.far;
    }

    // отсечение дальних чанков (экономия GPU на Android)
    this.cullT += dt;
    if (this.cullT > 0.15 && this.city) {
      this.cullT = 0;
      const far = this.fog.far + 120;
      const cp = cam.position;
      this.city.group.children.forEach((o) => {
        if (o.userData.noCull) return;
        const g = (o as THREE.Mesh).geometry;
        const bs = g.boundingSphere;
        if (!bs) return;
        const d = Math.hypot(bs.center.x - cp.x, bs.center.y - cp.y, bs.center.z - cp.z) - bs.radius;
        o.visible = d < far;
      });
    }

    this.poseT += dt;
    if (this.poseT > 0.06) {
      this.poseT = 0;
      const yaw = this.mode === "orbit" ? cam.rotation.y : this.yaw;
      this.onPose?.({ x: cam.position.x, z: cam.position.z, yaw });
    }
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.disposers.forEach((d) => d());
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}

function clamp(v: number, a: number, b: number) {
  return Math.min(b, Math.max(a, v));
}

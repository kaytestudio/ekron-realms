import * as THREE from "three";
import { GLTFExporter } from "three/examples/jsm/exporters/GLTFExporter.js";
import JSZip from "jszip";
import type { CityData } from "./generateCity";
import { GODOT_SNIPPET, LIBGDX_SNIPPET, README, UNITY_LOADER } from "./docs";

export function downloadBlob(name: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export async function exportGLB(city: CityData): Promise<Blob> {
  // UV нужны только фасадам — у остальных мешей вырезаем (-18% размера файла)
  const root = new THREE.Group();
  root.name = city.group.name;
  const temp: THREE.BufferGeometry[] = [];
  city.group.children.forEach((o) => {
    const m = o as THREE.Mesh;
    if (!m.isMesh) return;
    let g = m.geometry;
    if ((m.material as THREE.Material).name !== "Facade") {
      g = g.clone();
      g.deleteAttribute("uv");
      temp.push(g);
    }
    const nm = new THREE.Mesh(g, m.material);
    nm.name = m.name;
    root.add(nm);
  });
  const exporter = new GLTFExporter();
  const result = await exporter.parseAsync(root, { binary: true, maxTextureSize: 1024 });
  temp.forEach((g) => g.dispose());
  return new Blob([result as ArrayBuffer], { type: "model/gltf-binary" });
}

const r1 = (v: number) => Math.round(v * 10) / 10;

export function cityJSON(city: CityData): string {
  const data = {
    version: 1,
    generator: "ruined-city",
    seed: city.options.seed,
    blocks: city.options.blocks,
    destruction: city.options.destruction,
    half: r1(city.half),
    units: "meters, Y-up, right-handed (glTF)",
    colliders: city.colliders.map((c) => ({ x: r1(c.x), z: r1(c.z), hw: r1(c.hw), hd: r1(c.hd), h: r1(c.h) })),
    spawns: city.spawns.map((s) => ({ x: r1(s.x), z: r1(s.z), yaw: Math.round(s.yaw * 100) / 100 })),
    fires: city.fires.map((f) => ({ x: r1(f.x), y: r1(f.y), z: r1(f.z) })),
    craters: city.craters.map((c) => ({ x: r1(c.x), z: r1(c.z), r: r1(c.r) })),
  };
  return JSON.stringify(data);
}

export async function exportSourcesZip(): Promise<Blob> {
  const files = import.meta.glob(["/src/**/*.{ts,tsx,css}", "/index.html", "/package.json", "/vite.config.ts", "/tsconfig.json"], {
    query: "?raw",
    import: "default",
    eager: true,
  }) as Record<string, string>;
  const zip = new JSZip();
  const root = zip.folder("ruined-city")!;
  for (const [path, content] of Object.entries(files)) root.file(path.replace(/^\//, ""), content);
  root.file("README.md", README);
  root.file("unity/CityMapLoader.cs", UNITY_LOADER);
  root.file("godot/city_loader.gd", GODOT_SNIPPET);
  root.file("libgdx/Loader.java", LIBGDX_SNIPPET);
  return zip.generateAsync({ type: "blob", compression: "DEFLATE" });
}

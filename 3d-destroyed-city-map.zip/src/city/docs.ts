export const UNITY_LOADER = String.raw`using UnityEngine;

// Положите ruined_city.json в Assets/Resources и перетащите ruined_city.glb в сцену
// (нужен пакет glTFast: Window > Package Manager > Add by name: com.unity.cloud.gltfast).
// Скрипт создаёт BoxCollider'ы для зданий и ставит игрока на случайный спавн.
[System.Serializable] public class CBox   { public float x, z, hw, hd, h; }
[System.Serializable] public class CSpawn { public float x, z, yaw; }
[System.Serializable] public class CityData { public float half; public CBox[] colliders; public CSpawn[] spawns; }

public class CityMapLoader : MonoBehaviour
{
    public Transform player;

    void Start()
    {
        var data = JsonUtility.FromJson<CityData>(Resources.Load<TextAsset>("ruined_city").text);
        var root = new GameObject("CityColliders").transform;

        foreach (var b in data.colliders)
        {
            var go = new GameObject("Building");
            go.transform.SetParent(root);
            // glTFast зеркалит ось Z (three.js — правая система, Unity — левая)
            go.transform.position = new Vector3(b.x, b.h / 2f, -b.z);
            var bc = go.AddComponent<BoxCollider>();
            bc.size = new Vector3(b.hw * 2f, b.h, b.hd * 2f);
        }

        var s = data.spawns[Random.Range(0, data.spawns.Length)];
        player.position = new Vector3(s.x, 1.2f, -s.z);
    }
}
`;

export const GODOT_SNIPPET = String.raw`extends Node3D
# Godot 4: перетащите ruined_city.glb в проект, ruined_city.json положите рядом.

func _ready():
    var scene = load("res://ruined_city.glb").instantiate()
    add_child(scene)
    var data = JSON.parse_string(FileAccess.get_file_as_string("res://ruined_city.json"))
    for b in data.colliders:
        var body = StaticBody3D.new()
        var shape = CollisionShape3D.new()
        var box = BoxShape3D.new()
        box.size = Vector3(b.hw * 2, b.h, b.hd * 2)
        shape.shape = box
        body.add_child(shape)
        body.position = Vector3(b.x, b.h / 2.0, b.z)   # оси совпадают с three.js
        add_child(body)
    var sp = data.spawns.pick_random()
    $Player.position = Vector3(sp.x, 1.2, sp.z)
`;

export const LIBGDX_SNIPPET = String.raw`// libGDX + gdx-gltf (https://github.com/mgsx-dev/gdx-gltf), build.gradle:
//   implementation "com.github.mgsx-dev.gdx-gltf:gltf:2.2.1"
SceneAsset asset = new GLBLoader().load(Gdx.files.internal("ruined_city.glb"));
Scene scene = new Scene(asset.scene);
sceneManager.addScene(scene);
// Коллайдеры/спавны: разберите ruined_city.json через com.badlogic.gdx.utils.JsonReader
`;

export const README = `# Ruined City — процедурная 3D-карта «Разрушенный город»

Генератор огромного разрушенного города для мобильной игры (Android).

## Что внутри
- src/city/generateCity.ts — ГЕНЕРАТОР города (Three.js, без DOM). Здесь всё: сетка улиц,
  кварталы, здания с обрушенными верхушками и оголённым каркасом, пробоины, завалы,
  воронки, сгоревшие машины, баррикады, фонари, мёртвые деревья, очаги пожаров.
- src/city/textures.ts — процедурная текстура фасадов (целые/разбитые/выгоревшие окна).
- src/city/view.ts — просмотрщик (камера, ходьба/полёт/обзор, небо, дым, погода).
- src/city/exporters.ts — экспорт в GLB / JSON / ZIP.
- src/App.tsx и src/components — интерфейс (React + Tailwind).

## Запуск
    npm install
    npm run dev        # режим разработки
    npm run build      # сборка

## Экспорт для игры
1. Нажмите «Скачать GLB» — получите ruined_city.glb (геометрия + вертексные цвета + текстура фасадов).
2. Нажмите «Скачать JSON» — ruined_city.json: коллайдеры зданий (AABB), точки спавна, очаги огня, воронки.
3. Импортируйте в Unity (glTFast), Godot 4 (нативно), Unreal (Interchange/Datasmith glTF), libGDX (gdx-gltf),
   jMonkeyEngine, Babylon/Three.js (WebView) — см. примеры кода в приложении.

## Оптимизация под Android
- Вся геометрия слита в чанки по 200 м и 3 материала => несколько десятков draw call'ов.
- Нет динамических теней и прозрачности (кроме дыма) — подходит для бюджетных устройств.
- Для камеры используйте дальность отсечения 400–600 м и туман (как в просмотрщике).
- Размеры карты: 8x8 (~1 км), 12x12, 16x16 (~1.3 км), 24x24 (~2 км) кварталов.
- Сид (seed) — одинаковая карта у всех игроков: можно хранить только число!

## Система координат
Y вверх, метры, правосторонняя (как glTF). В Unity ось Z зеркалится загрузчиком glTFast.
`;
